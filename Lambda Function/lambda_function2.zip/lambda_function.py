import json
import urllib.parse
import boto3

s3 = boto3.client('s3')

def lambda_handler(event, context):
    # Get the bucket name and key of the new object
    bucket_name = event['Records'][0]['s3']['bucket']['name']
    object_key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')

    # Get the contents of the new object
    obj = s3.get_object(Bucket=bucket_name, Key=object_key)
    obj_content = obj['Body'].read().decode('utf-8')
    
    # Print the contents of the new object
    print('New S3 object created:')
    print(f'Bucket: {bucket_name}')
    print(f'Key: {object_key}')
    print(f'Contents: {obj_content}')
