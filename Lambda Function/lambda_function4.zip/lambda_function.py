import json
import boto3

# Create an SNS client
sns = boto3.client('sns')

def lambda_handler(event, context):
    # Get the details from the S3 event
    bucket_name = event['Records'][0]['s3']['bucket']['name']
    object_key = event['Records'][0]['s3']['object']['key']

    # Read the content of the S3 object
    s3 = boto3.resource('s3')
    obj = s3.Object(bucket_name, object_key)
    body = obj.get()['Body'].read().decode('utf-8')

    # Publish a message to the SNS topic
    message = {
        'default': body
    }
    response = sns.publish(
        TopicArn='arn:aws:sns:ap-southeast-1:466331843672:smart_pill_sns',
        Message=json.dumps(message),
        MessageStructure='json'
    )
    return {
        'statusCode': 200,
        'body': json.dumps('Message published to SNS topic!')
    }
