import json

import requests

def lambda_handler(event, context):
    # Retrieve timing value from the input JSON
    timing = event['timing']
    
    # Construct message with timing value
    message = f"Dispense pill at {timing} NOW"
    
    # Send HTTP post request to device
    url = "http://<device-ip-address>/dispense"
    headers = {"Content-Type": "application/json"}
    data = {"message": message}
    response = requests.post(url, headers=headers, json=data)
    
    # Return JSON response with message
    if response.status_code == 200:
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': f"Successfully sent message '{message}' to device"
            })
        }
    else:
        return {
            'statusCode': response.status_code,
            'body': json.dumps({
                'message': f"Failed to send message '{message}' to device: {response.reason}"
            })
        }
