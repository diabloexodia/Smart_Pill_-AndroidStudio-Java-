import RPi.GPIO as GPIO
import math
import time
import datetime
from luma.core.interface.serial import i2c, spi, pcf8574
from luma.core.interface.parallel import bitbang_6800
from luma.core.render import canvas
from luma.oled.device import ssd1306, ssd1309, ssd1325, ssd1331, sh1106, sh1107, ws0010
GPIO.setmode(GPIO.BOARD)
GPIO.setup(10, GPIO.IN)
GPIO.setup(11, GPIO.OUT)
#GPIO.setup(35, GPIO.OUT)
serial = i2c(port=1, address=0x3c)
device = sh1106(serial)

#getting data from s3 bucket
import boto3

s3 = boto3.client('s3',
                  aws_access_key_id='AKIAWZE4LHRMDMAQAMUT',
                  aws_secret_access_key='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',
                  region_name='ap-southeast-1')

bucket_name = 'smartpills'
object_key = 'userdetails/userdetails.txt'
local_file_path = '/home/rpi/test_code/s3bucket_text.txt'



def main():
    today_last_time = "Unknown"
    flag = 0
    while True:
        s3.download_file(bucket_name, object_key, local_file_path)

        with open(local_file_path, 'r') as f:
            file_contents = f.read()
        print(file_contents)
        current_time = datetime.datetime.now()
        #print(current_time)
        #print(flag)
        time_list = []
        PillId = ''
        dosage = 0
        with open('/home/rpi/test_code/s3bucket_text.txt', 'r') as file:
            for line in file:
                if line.startswith('Name:'):
                    # Extract name if needed
                    name = line.strip().split(': ')[1]
                elif line.startswith('Time:'):
                # Extract time and add to list
                    time_str = line.strip().split(': ')[1]
                    time_list += time_str.split(',')
                elif line.startswith('Pill Name:'):
                # Extract pill name
                    PillId = line.strip().split(': ')[1]
                elif line.startswith('Dosage:'):
                # Extract dosage
                    dosage = line.strip().split(': ')[1]

        print('Time List:', time_list)
        print('Pill Id:', PillId)
        print('Dosage:', dosage)


if __name__ == "__main__":
    try:
        #device = get_device()
        main()
    except KeyboardInterrupt:
        pass