import pygame

# Initialize pygame mixer
pygame.mixer.init()

# Load the audio file
hello_sound = pygame.mixer.Sound("Take_pill.wav")

# Play the audio file
hello_sound.play()

# Wait for the audio to finish playing
pygame.time.wait(int(hello_sound.get_length() * 1000))

# Clean up pygame mixer
pygame.mixer.quit()
