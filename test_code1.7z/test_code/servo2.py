import RPi.GPIO as GPIO
import time

# Set the GPIO mode to BCM
GPIO.setmode(GPIO.BCM)

# Set the servo motor pin
servo_pin = 14

# Set the duty cycle range for the servo motor
servo_min = 2.5
servo_max = 12.5

# Function to control the servo motor
def control_servo(angle):
    duty_cycle = servo_min + (angle/180.0) * (servo_max - servo_min)
    GPIO.output(servo_pin, True)
    time.sleep(duty_cycle / 1000.0)
    GPIO.output(servo_pin, False)
    time.sleep(20/1000.0 - duty_cycle / 1000.0)

# Set up the servo motor pin as an output
GPIO.setup(servo_pin, GPIO.OUT)

# Main loop to rotate the servo motor continuously
while True:
    # Rotate the servo motor to 0 degrees (starting position)
    control_servo(0)
    time.sleep(1)  # Delay for 1 second

    # Rotate the servo motor to 180 degrees (ending position)
    control_servo(180)
    time.sleep(1)  # Delay for 1 second

# Clean up GPIO
GPIO.cleanup()
