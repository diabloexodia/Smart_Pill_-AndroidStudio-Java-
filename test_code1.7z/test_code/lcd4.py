import Adafruit_SSD1306
from datetime import datetime

RST = 2

# 128x64 display with hardware I2C:
disp = Adafruit_SSD1306.SSD1306_128_64(rst=RST)

# Initialize library.
disp.begin()

# Clear display.
disp.clear()
disp.display()

# Get current time
timenow = datetime.now().strftime('%I:%M %p')

# Create image
disp.create_image_from_text(timenow)

# Display image
disp.image(image)
disp.display()
