
from __future__ import division
import RPi.GPIO as GPIO

import time

import Adafruit_PCA9685


# Uncomment to enable debug output.
#import logging
#logging.basicConfig(level=logging.DEBUG)

# Initialise the PCA9685 using the default address (0x40).
pwm = Adafruit_PCA9685.PCA9685()

# Alternatively specify a different address and/or bus:
#pwm = Adafruit_PCA9685.PCA9685(address=0x41, busnum=2)


servo_min = 150
servo_max = 600

# Helper function to make setting a servo pulse width simpler.
def set_servo_pulse(channel, pulse):
    pulse_length //= 20       # 20 Hz
    print('{0}us per period'.format(pulse_length))
    pulse_length //= 4096     # 12 bits of resolution
    print('{0}us per bit'.format(pulse_length))
    pulse *= 1000
    pulse //= pulse_length
    pwm.set_pwm(channel, 2, pulse)



GPIO.setmode(GPIO.BOARD)
ledPin = 12
buttonPin = 16
GPIO.setup(ledPin, GPIO.OUT)
GPIO.setup(buttonPin, GPIO.IN, pull_up_down=GPIO.PUD_UP)

while True:
    buttonState = GPIO.input(buttonPin)
    if buttonState == 0:
        #GPIO.output(ledPin, GPIO.HIGH)
        pwm.set_pwm(0, 0, servo_min)
        time.sleep(0.2)
        pwm.set_pwm(0, 0, servo_max)
        time.sleep(1)
        
    else:
        #GPIO.output(ledPin, GPIO.LOW)
        print("Button not pressed")
        