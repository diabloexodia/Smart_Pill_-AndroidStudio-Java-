
import boto3
s3 = boto3.client('s3',
                  aws_access_key_id='AKIAWZE4LHRMDMAQAMUT',
                  aws_secret_access_key='/rjMk9by0v2ZIvY2SIQgKDhF/A8eaaSnzEA9LB0SF',
                  region_name='ap-southeast-1')

bucket_name = 'smartpills'
object_key = 'userdetails/userdetails.txt'
local_file_path = '/home/rpi/test_code/s3bucket_text.txt'
with open(local_file_path, 'r') as f:
    file_contents = f.read()

print(file_contents)
#with open(local_file_path, 'r') as f:
#    file_contents = f.read()
#    PatientName,TimeofConsumption,Dosage,PillId = file_contents.split(',')
#    set_time = TimeofConsumption

# Display the contents of the text file on the Raspberry Pi output
#print('Patient Name:',PatientName)
#print('Time of consumption:',TimeofConsumption)
#print('Dosage(Nos):',Dosage)
#print('Pill Id:',PillId)
#print('Time Set:',set_time)


#set_hour, set_minute = set_time.split(':')
#print('Time Set:',set_hour)
#print('Time Set:',set_minute)

#print(file_contents)