from rpi_hardware_pwm import HardwarePWM
pwm = HardwarePWM(pwm_channel = 0, hz = 60)
pwm.start(100)
pwm.change_duty_cycle(50)
pwm.change_frequency(25_000)
pwm.stop()

"""
# Initialize the PCA9685 using the default address (0x40).
pwm.start(0x40, debug=True)

# Set the PWM frequency to 60hz.
pwm.set_pwm_freq(60)
pwm.set_pwm(0, 0, 0)

# Set the PWM duty cycle for channel 0 to the value 70.
pwm.set_pwm(0, 0, 90)
"""