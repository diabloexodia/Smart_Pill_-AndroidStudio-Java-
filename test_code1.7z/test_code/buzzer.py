from gpiozero import Buzzer
#import RPi.GPIO as GPIO
from time import sleep
#GPIO.setmode(GPIO.BOARD)
#GPIO.setup(35, GPIO.OUT)
buzzer = Buzzer(19)
while True:
    #buzzer.on()
    sleep(1)
    #GPIO.output(35, GPIO.LOW)
    buzzer.off()
    sleep(3)