import RPi.GPIO as GPIO
import time

# Set the GPIO mode to BCM
GPIO.setmode(GPIO.BCM)

# Set the servo motor pin
servo_pin = 17

# Set the duty cycle range for the servo motor
servo_min = 2.5
servo_max = 12.5

# Set the time for the servo motor to rotate
rotation_time = "02:30"  # Adjust this to your desired time

# Function to control the servo motor
def control_servo(angle):
    duty_cycle = servo_min + (angle/180.0) * (servo_max - servo_min)
    GPIO.output(servo_pin, True)
    time.sleep(duty_cycle / 1000.0)
    GPIO.output(servo_pin, False)
    time.sleep(20/1000.0 - duty_cycle / 1000.0)

# Set up the servo motor pin as an output
GPIO.setup(servo_pin, GPIO.OUT)

# Main loop
while True:
    current_time = time.strftime("%H:%M", time.localtime())

    if current_time == rotation_time:
        # Time for servo motor to rotate
        control_servo(90)  # Rotate to 90 degrees
        
    # Delay for 1 minute before checking the time again
    time.sleep(60)

# Clean up GPIO
GPIO.cleanup()
