import RPi.GPIO as GPIO
import math
import time
import datetime
from luma.core.interface.serial import i2c, spi, pcf8574
from luma.core.interface.parallel import bitbang_6800
from luma.core.render import canvas
from luma.oled.device import ssd1306, ssd1309, ssd1325, ssd1331, sh1106, sh1107, ws0010
GPIO.setmode(GPIO.BOARD)
GPIO.setup(10, GPIO.IN)
serial = i2c(port=1, address=0x3c)
device = sh1106(serial)
#sensor = 15

set_hour = 21
set_minute = 43
def posn(angle, arm_length):
    dx = int(math.cos(math.radians(angle)) * arm_length)
    dy = int(math.sin(math.radians(angle)) * arm_length)
    return (dx, dy)

def main():
    today_last_time = "Unknown"
    flag = 0
    while True:
        current_time = datetime.datetime.now()
        print(current_time)
        if current_time.hour == set_hour and current_time.minute == set_minute:
            if GPIO.input(10) == False:
                if(flag == 0):
                    with open("servotest.py") as f:
                        exec(f.read())
                    flag = 1

        if current_time.minute == set_minute + 1:
            flag = 0

        if GPIO.input(10) == True:
            with canvas(device) as draw:
                draw.rectangle(device.bounding_box, outline="white", fill="black")
                draw.text((10, 40), "No Dispenser ", fill="white")
            time.sleep(0.2)
            #print("No motion")
        else:
            #print("motion")
            #with open("servotest.py") as f:
            #    exec(f.read())

            with canvas(device) as draw:
                now = datetime.datetime.now()
                today_date = now.strftime("%d %b %y")
                today_time = now.strftime("%H:%M:%S")
                if today_time != today_last_time:
                    today_last_time = today_time
                    draw.rectangle(device.bounding_box, outline="white", fill="black")
                    draw.text((10, 40), today_date+' '+today_time, fill="white")
            time.sleep(1)

if __name__ == "__main__":
    try:
        #device = get_device()
        main()
    except KeyboardInterrupt:
        pass